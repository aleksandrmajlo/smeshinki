-- Adminer 4.8.1 MySQL 5.7.33 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `anecdotes`;
CREATE TABLE `anecdotes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `anecdotes` (`id`, `title`, `description`, `slug`, `meta_title`, `meta_description`, `created_at`, `updated_at`) VALUES
(2,	'Анекдот  1',	'<p><span style=\"background-color:rgb(255,255,255);color:rgb(0,0,0);\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras dapibus arcu a nibh lacinia, nec convallis mauris mollis. Ut facilisis aliquet est sed interdum. Morbi est arcu, viverra eget accumsan nec, varius a metus. Vivamus quis hendrerit elit, nec luctus risus. Vivamus in pellentesque orci, semper auctor augue. Aliquam elementum nisi ante, ultrices auctor justo tincidunt in. Curabitur ut imperdiet nunc.</span></p>',	'anektod-1',	'Анекдот  1',	'Анекдот  1',	'2022-05-02 07:11:44',	'2022-05-02 11:39:18'),
(3,	'Анекдот  2',	'<p><span style=\"background-color:rgb(255,255,255);color:rgb(0,0,0);\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras dapibus arcu a nibh lacinia, nec convallis mauris mollis. Ut facilisis aliquet est sed interdum. Morbi est arcu, viverra eget accumsan nec, varius a metus. Vivamus quis hendrerit elit, nec luctus risus. Vivamus in pellentesque orci, semper auctor augue. Aliquam elementum nisi ante, ultrices auctor justo tincidunt in. Curabitur ut imperdiet nunc.</span></p>',	'anektod-2',	'Анекдот  2',	'Анекдот  2',	'2022-05-02 07:12:05',	'2022-05-02 11:38:57'),
(4,	'Анекдот  3',	'<p><span style=\"background-color:rgb(255,255,255);color:rgb(0,0,0);\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras dapibus arcu a nibh lacinia, nec convallis mauris mollis. Ut facilisis aliquet est sed interdum. Morbi est arcu, viverra eget accumsan nec, varius a metus. Vivamus quis hendrerit elit, nec luctus risus. Vivamus in pellentesque orci, semper auctor augue. Aliquam elementum nisi ante, ultrices auctor justo tincidunt in. Curabitur ut imperdiet nunc.</span></p>',	'anektod-3',	'Анекдот  3',	'Анекдот  3',	'2022-05-02 07:12:19',	'2022-05-02 11:38:17');

DROP TABLE IF EXISTS `calendars`;
CREATE TABLE `calendars` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `typecalendar_id` int(11) unsigned DEFAULT NULL,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `calendars` (`id`, `title`, `date`, `slug`, `typecalendar_id`, `meta_title`, `meta_description`, `created_at`, `updated_at`) VALUES
(1,	'Трійця',	'2022-06-24',	'triycya',	5,	'Трійця',	'Трійця',	'2022-05-02 05:19:04',	'2022-05-07 17:17:54'),
(2,	'Інше свято цього дня',	'2022-05-08',	'den-pam-yati-ta-primirennya',	4,	'Інше свято цього дня',	'Інше свято цього дня',	'2022-05-02 11:54:57',	'2022-05-21 09:32:58'),
(3,	'День пам\'яті та примирення',	'2022-05-08',	'den-pam-yati-ta-primirennya-tip-zagalniy',	3,	'День пам\'яті та примирення',	'День пам\'яті та примирення',	'2022-05-07 17:17:44',	'2022-05-21 09:28:47');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_resets_table',	1),
(3,	'2019_08_19_000000_create_failed_jobs_table',	1),
(4,	'2019_12_14_000001_create_personal_access_tokens_table',	1),
(5,	'2022_04_28_171320_create_words_table',	1),
(6,	'2022_05_01_211633_create_anecdotes_table',	2),
(7,	'2022_05_02_061816_create_сalendars_table',	3),
(8,	'2022_05_02_064550_create_posts_table',	4),
(9,	'2022_05_02_074928_create_calendars_table',	5),
(10,	'2022_05_03_061108_add_paid_to_words_table',	6),
(11,	'2022_05_07_191725_create_typecalendars_table',	7),
(12,	'2022_05_21_154502_add_role_column_to_users_table',	8),
(13,	'2022_05_21_170409_create_post_user_table',	9),
(14,	'2022_05_21_195936_create_welcomes_table',	10),
(15,	'2022_05_22_064038_create_ratings_table',	11);

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `video` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `calendar_id` int(11) unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `rating_avg` double(8,2) NOT NULL DEFAULT '0.00',
  `total_votes` int(11) unsigned NOT NULL DEFAULT '0',
  `total_rating` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `posts` (`id`, `title`, `text`, `video`, `photo`, `calendar_id`, `slug`, `meta_title`, `meta_description`, `created_at`, `updated_at`, `rating_avg`, `total_votes`, `total_rating`) VALUES
(1,	'Трійця',	'<p><span style=\"background-color:rgb(255,255,255);color:rgb(32,33,34);\">Свята Трійця&nbsp;— ім\'я Живого Бога в православ\'ї і тринитарному християнстві, Єдиного в Трьох Особах, іпостасях Божества, Отці, Сину і Святому Дусі. Цікаво, що сучасні українські неоязичники (рідновіри) звертають увагу, що віра у Триєдиного Бога (див. </span><a href=\"https://uk.wikipedia.org/wiki/%D0%A2%D1%80%D0%B8%D0%B3%D0%BB%D0%B0%D0%B2\">Триглав</a><span style=\"background-color:rgb(255,255,255);color:rgb(32,33,34);\">) була відома індоєвропейським народам ще задовго до народження Христа, що можна вважати викликом для сучасних християн, які нерідко погано розуміють відмінність християнського бачення Бога-Трійці від дохристиянського.</span></p>',	NULL,	NULL,	1,	'triycya',	'Трійця',	'Трійця',	'2022-05-02 06:20:36',	'2022-05-02 06:21:12',	0.00,	0,	0),
(2,	'Свято 1 -08,05,22',	'<p><span style=\"background-color:rgb(255,255,255);color:rgb(51,51,51);\">Українці воювали на боці антигітлерівської коаліції (Об’єднаних Націй) і зробили значний внесок у перемогу над нацизмом та союзниками гітлерівської Німеччини. Ціною цього стали надзвичайні втрати упродовж 1939–1945 років – українців та інших народів, які проживали на нашій землі й боролися проти тоталітарних режимів. Тоді загинуло понад вісім мільйонів осіб. Ми добре знаємо ціну війни, тому плекаємо мир</span></p>',	NULL,	NULL,	2,	'dnya-pam-yati-ta-primirennya',	'Дня пам’яті та примирення',	'Дня пам’яті та примирення',	'2022-05-02 12:12:58',	'2022-05-21 09:41:38',	0.00,	0,	0),
(3,	'Свято 2 -08,05,22',	'<p><span style=\"background-color:rgb(255,255,255);color:rgb(51,51,51);\">Українці воювали на боці антигітлерівської коаліції (Об’єднаних Націй) і зробили значний внесок у перемогу над нацизмом та союзниками гітлерівської Німеччини. Ціною цього стали надзвичайні втрати упродовж 1939–1945 років – українців та інших народів, які проживали на нашій землі й боролися проти тоталітарних режимів. Тоді загинуло понад вісім мільйонів осіб. Ми добре знаємо ціну війни, тому плекаємо мир</span></p>',	NULL,	NULL,	2,	'dnya-pam-yati-ta-primirennya-2',	'Дня пам’яті та примирення',	'Дня пам’яті та примирення',	'2022-05-02 13:33:18',	'2022-05-21 09:41:22',	0.00,	0,	0),
(4,	'Свято 3 -08,05,22',	'',	'files/uploads/5c5cd81dc154c291958b974d15613eae.mp4',	'images/uploads/e678ecde1e1678442a43fb8bacbab9fe.jpg',	2,	'dnya-pam-yati-ta-primirennya-3',	'Дня пам’яті та примирення',	'Дня пам’яті та примирення',	'2022-05-08 03:05:06',	'2022-05-21 09:41:10',	0.00,	0,	0),
(5,	'Свято 4 -08,05,22',	'',	NULL,	'images/uploads/14caa622fd3e2811740fc7324adac7f4.jpg',	2,	'dnya-pam-yati-ta-primirennya-4',	'Дня пам’яті та примирення',	'Дня пам’яті та примирення',	'2022-05-08 03:05:29',	'2022-05-21 09:40:59',	0.00,	0,	0),
(6,	'Дня пам’яті та примирення  для загального',	'<p><span style=\"background-color:rgb(249,250,252);color:rgb(71,86,105);\">Мутатор преобразует значение атрибута в момент их присвоения экземпляру Eloquent. Чтобы определить мутатор, определите метод </span><code>set{Attribute}Attribute</code><span style=\"background-color:rgb(249,250,252);color:rgb(71,86,105);\"> в вашей модели, где </span><code>{Attribute}</code><span style=\"background-color:rgb(249,250,252);color:rgb(71,86,105);\"> – это имя столбца, к которому вы хотите получить доступ, в «верхнем» регистре.</span></p>',	'files/uploads/5c5cd81dc154c291958b974d15613eae.mp4',	'images/uploads/e678ecde1e1678442a43fb8bacbab9fe.jpg',	3,	'dnya-pam-yati-ta-primirennya-dlya-zagalnogo',	'Дня пам’яті та примирення',	'Дня пам’яті та примирення',	'2022-05-08 04:58:21',	'2022-05-22 05:12:52',	5.00,	1,	5),
(7,	'Свято 1 -08,05,22',	'<p><span style=\"background-color:rgb(255,255,255);color:rgb(51,51,51);\">Українці воювали на боці антигітлерівської коаліції (Об’єднаних Націй) і зробили значний внесок у перемогу над нацизмом та союзниками гітлерівської Німеччини. Ціною цього стали надзвичайні втрати упродовж 1939–1945 років – українців та інших народів, які проживали на нашій землі й боролися проти тоталітарних режимів. Тоді загинуло понад вісім мільйонів осіб. Ми добре знаємо ціну війни, тому плекаємо мир</span></p>',	NULL,	NULL,	3,	'svyato-1-08-05-22',	'Дня пам’яті та примирення',	'Дня пам’яті та примирення',	'2022-05-21 15:08:22',	'2022-05-22 06:18:02',	3.50,	4,	14),
(8,	'Ше свято',	'<p><span style=\"background-color:rgb(255,255,255);color:rgb(0,0,0);\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sed enim posuere, ultrices orci in, condimentum est. Donec viverra risus a augue ultricies maximus. Ut vestibulum neque ultricies imperdiet tempor. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam eu vestibulum odio. Ut mollis libero nunc, sit amet sollicitudin enim tincidunt vitae. Maecenas sed leo vitae dolor euismod pulvinar vel id purus. Nam id ante lobortis, auctor est in, cursus ex. Vestibulum ullamcorper pellentesque magna nec facilisis. Proin a metus facilisis velit pretium tempor. Aenean ut felis commodo, pellentesque leo et, venenatis sem. Sed odio ex, tristique ac condimentum quis, dictum nec tortor. Suspendisse dui est, vulputate nec felis ut, fringilla pharetra metus. Sed eu eleifend libero. Sed egestas at metus ut laoreet. Aenean at nisl consectetur, eleifend nisi eget, ultricies dolor.</span></p>',	NULL,	'images/uploads/3158a7e2e004096f533330c981736e84.jpg',	3,	'she-svyato',	'Ше свято',	'Ше свято',	'2022-05-22 04:10:24',	'2022-05-22 05:12:46',	4.50,	2,	9);

DROP TABLE IF EXISTS `post_user`;
CREATE TABLE `post_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `post_user_user_id_index` (`user_id`),
  KEY `post_user_post_id_index` (`post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `post_user` (`id`, `user_id`, `post_id`) VALUES
(4,	2,	6);

DROP TABLE IF EXISTS `ratings`;
CREATE TABLE `ratings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `rating_avg` double(8,2) NOT NULL COMMENT 'средняя оценка',
  `total_votes` int(11) NOT NULL COMMENT 'количество оценок',
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `typecalendars`;
CREATE TABLE `typecalendars` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `typecalendars` (`id`, `title`, `slug`, `meta_title`, `meta_description`, `created_at`, `updated_at`) VALUES
(3,	'Загальний',	'zagalniy',	'Загальний',	'Загальний',	'2022-05-07 17:08:46',	'2022-05-07 17:08:46'),
(4,	'Державний',	'derzhavniy',	'Державний',	'Державний',	'2022-05-07 17:09:14',	'2022-05-07 17:09:14'),
(5,	'Церковний',	'cerkovniy',	'Церковний',	'Церковний',	'2022-05-07 17:09:48',	'2022-05-07 17:09:48'),
(6,	'Професійний',	'profesiyniy',	'Професійний',	'Професійний',	'2022-05-07 17:10:22',	'2022-05-07 17:10:22');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` enum('user','manager','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `role`) VALUES
(1,	'smeshinki@gmail.com',	'smeshinki@gmail.com',	NULL,	'$2y$10$lzJ3H6SETofbSGLgsJ4zRuRGZ4UQJk/YeThh8uyHeEVOHZV9vUUAC',	'XjSqB6pvnSAwBpUDD7pvo6VlevSRq3iKakebHWzVU3K7Ukzrl7SINby9cJ0x',	'2022-05-02 06:47:49',	'2022-05-02 06:47:49',	'admin'),
(2,	'test',	'smeshinki2@gmail.com',	NULL,	'$2y$10$ZkSzk9SmudgTaIQxeK91p.wTDSjPjruUZjIkj3bMZEffJKv/CGc7e',	'YQT8KXLFnxcYGo86vY1FId1HZhsYgu5PU9ZzP8I2TdbnbZOFUeeYk5cWaMJW',	'2022-05-21 13:11:29',	'2022-05-21 13:11:29',	'user');

DROP TABLE IF EXISTS `welcomes`;
CREATE TABLE `welcomes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `welcome` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `welcomes` (`id`, `name`, `email`, `user_id`, `welcome`, `photo`, `status`, `created_at`, `updated_at`) VALUES
(7,	NULL,	NULL,	2,	'цукцук',	NULL,	0,	'2022-05-21 18:10:16',	'2022-05-21 18:10:16'),
(8,	NULL,	NULL,	2,	'ВФЫВ',	'images/uploads/welcome_1653167424.jpg',	0,	'2022-05-21 18:10:24',	'2022-05-21 18:10:24'),
(9,	NULL,	NULL,	2,	'S',	'images/uploads/welcome_1653167547.jpg',	0,	'2022-05-21 18:12:27',	'2022-05-21 18:12:27');

DROP TABLE IF EXISTS `words`;
CREATE TABLE `words` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `telegram_id` int(11) DEFAULT NULL COMMENT 'message_id с телеги',
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `show_title` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'показать описание',
  PRIMARY KEY (`id`),
  KEY `words_telegram_id_index` (`telegram_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `words` (`id`, `title`, `photo`, `video`, `description`, `telegram_id`, `slug`, `meta_title`, `meta_description`, `created_at`, `updated_at`, `show_title`) VALUES
(2,	'Горить',	NULL,	'files/uploads/713c7776a020e6bb21f121d8ad082cb3.MP4',	'<p>Горить</p>',	NULL,	'gorit',	'Горить',	'Горить',	'2022-05-02 07:07:51',	'2022-05-02 07:07:51',	0),
(3,	'азов',	'images/uploads/c11fa0bc180309b4edb06b123219a5e6.jpg',	NULL,	'',	NULL,	'azov',	'азов',	'азов',	'2022-05-02 07:09:30',	'2022-05-02 07:09:30',	0),
(4,	'переживу',	'images/uploads/a9db092a60988a97d7ea7fe173225ed8.jpg',	NULL,	'<p style=\"margin-left:0px;\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eu mi eget massa lobortis pretium. Sed vulputate turpis leo, ut ornare purus pulvinar id. Cras rhoncus id ex lacinia efficitur. Morbi sed iaculis sem, non malesuada magna. Curabitur sit amet sem vel ipsum vestibulum viverra ac vitae eros. Integer venenatis maximus arcu, ac accumsan velit euismod vitae. Vivamus tempor eleifend convallis. Nam condimentum tincidunt mauris id sollicitudin.</p><p style=\"margin-left:0px;\">Fusce laoreet, metus sit amet bibendum tincidunt, dui augue rutrum lectus, sed placerat ipsum dolor eget ex. Pellentesque rhoncus venenatis nulla sed viverra. Morbi ut porttitor est. Donec lorem nunc, laoreet nec varius vitae, cursus sed ligula. Maecenas nec congue neque. Etiam ut mauris pretium, ultrices sem ac, sodales augue. In facilisis consequat lacinia. Suspendisse enim tortor, pellentesque non vulputate id, vestibulum sit amet leo.</p>',	NULL,	'perezhivu',	'переживу',	'переживу',	'2022-05-02 07:10:51',	'2022-05-03 06:51:03',	1),
(5,	'Не вказана',	'images/uploads/7ed42ad9bf33ee67836b45c0a3a1e9d8.jpg',	NULL,	'',	NULL,	'ne-vkazana',	'3',	'3',	'2022-05-02 08:17:16',	'2022-05-02 08:21:55',	0),
(6,	'Не вказана',	'images/uploads/7b9e185c7685f9f3ae8bae47e4963435.jpg',	NULL,	'',	NULL,	'ne-vkazana-2',	'4',	'4',	'2022-05-02 08:28:06',	'2022-05-02 08:28:06',	0),
(7,	'Постійна рубрика! Боже, яке кончене...',	NULL,	'files/uploads/810c032af8bc1beac2848d31366e5967.mp4',	'',	NULL,	'postiyna-rubrika-bozhe-yake-konchene',	'Постійна рубрика! Боже, яке кончене...',	'Постійна рубрика! Боже, яке кончене...',	'2022-05-03 07:45:49',	'2022-05-03 07:45:57',	1);

-- 2022-05-22 11:23:13
